document.addEventListener('DOMContentLoaded', () => {
    const settingsIcon = document.querySelector('.settings-icon');

    

    const arrowButtons = document.querySelectorAll('.arrow-btn');

    

    // Configuração do gráfico
    const ctx = document.getElementById('serviceChart').getContext('2d');
    const serviceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Chamados Realizados', 'Chamados Respondidos', 'Chamados Não Respondidos'],
            datasets: [{
                label: 'Número de Chamados',
                data: [12, 8, 4], // Valores de exemplo
                backgroundColor: ['#37623A', '#3A6642', '#14273D'],
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    const serviceSelect = document.getElementById('serviceSelect');

    serviceSelect.addEventListener('change', () => {
        // Simula a atualização dos dados do gráfico ao trocar de serviço
        const selectedService = serviceSelect.value;
        let newData;

        switch (selectedService) {
            case 'buraco':
                newData = [12, 8, 4];
                break;
            case 'rede':
                newData = [15, 10, 5];
                break;
            case 'encanamento':
                newData = [20, 15, 5];
                break;
            case 'postes':
                newData = [10, 7, 3];
                break;
        }

        serviceChart.data.datasets[0].data = newData;
        serviceChart.update();
    });
});

// Funções para abrir e fechar os modais

function openCitizenModal(citizen) {
    document.getElementById(`${citizen}Modal`).style.display = 'block';
}

function closeCitizenModal(citizen) {
    document.getElementById(`${citizen}Modal`).style.display = 'none';
}

function openDisableModal(citizen) {
    document.getElementById('disableUserModal').style.display = 'block';
}

function openChatModal(service) {
    document.getElementById(`${service}Modal`).style.display = 'block';
}

function closeChatModal(service) {
    document.getElementById(`${service}Modal`).style.display = 'none';
}

function confirmDisable(citizen) {
    alert(`Usuário ${citizen} foi desabilitado!`);
    closeDisableModal(); 
    closeCitizenModal(citizen); 
}

function closeDisableModal() {
    document.querySelectorAll('.modal').forEach(modal => modal.style.display = 'none');
}

function openModal(modalId) {
    document.getElementById(`${modalId}Modal`).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(`${modalId}Modal`).style.display = 'none';
}

function openDetailsModal(terceirizado) {
    document.getElementById(`${terceirizado}Modal`).style.display = 'block';
}

function closeDetailsModal(terceirizado) {
    document.getElementById(`${terceirizado}Modal`).style.display = 'none';
}

// Adicione um listener para o botão "Terceirizados"
document.querySelector('.segment-control').addEventListener('click', function() {
    openModal('terceirizados');
});


function editCompany() {
    alert('Editado com Sucesso!');
}

function openDisableCompanyModal() {
    document.getElementById('disableCompanyModal').style.display = 'block';
}

function disableCompany() {
    alert('Empresa desabilitada com sucesso!');
    closeModal('disableCompany');
    closeDetailsModal('reparoBuracos');  // Fechar o modal da empresa após desabilitar
}

// Função para abrir o modal de configurações
document.querySelector('.settings-icon').addEventListener('click', function() {
    openModal('settings');
});

// Função de Logout
function logout() {
    window.location.href = 'index.html'; // Redireciona para a página de login
}

// Função para abrir o modal de desabilitar usuário
/*function openDisableUserModal() {
    document.getElementById('disableUserModal').style.display = 'block';
}*/

// Função para fechar o modal de desabilitar usuário
function closeDisableUserModal() {
    document.getElementById('disableUserModal').style.display = 'none';
}

// Função para desabilitar usuário
function disableUser() {
    const reason = document.getElementById('disableReason').value;
    if (reason.trim() !== '') {
        alert('Usuário Desabilitado');
        closeDisableUserModal();
        closeCitizenModal('outro', 'mais'); // ou outro usuário conforme necessário

        
    } else {
        alert('Por favor, insira um motivo.');
    }
    
        
}

// Função para abrir o modal de cadastro de terceirizado
function openCadastrarTerceirizadoModal() {
    document.getElementById('cadastrarTerceirizadoModal').style.display = 'block';
}

// Função para fechar o modal de cadastro de terceirizado
function closeCadastrarTerceirizadoModal() {
    document.getElementById('cadastrarTerceirizadoModal').style.display = 'none';
}

// Função para registrar o terceirizado
function registerTerceirizado() {
    // Aqui você pode adicionar a lógica para salvar os dados
    alert('Terceirizado Registrado!');
    closeCadastrarTerceirizadoModal();
}

// Adicionando evento ao botão de Cadastrar Terceirizado na lista
document.querySelector('.cadastrar-btn').addEventListener('click', openCadastrarTerceirizadoModal);



// Configuração do gráfico
const ctx = document.getElementById('serviceChart').getContext('2d');
const serviceChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Chamados Realizados', 'Chamados Respondidos', 'Chamados Não Respondidos'],
        datasets: [{
            label: 'Número de Chamados',
            data: [22, 12, 10], // Valores de exemplo
            backgroundColor: ['#37623A', '#3A6642', '#14273D'],
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

const serviceSelect = document.getElementById('serviceSelect');

serviceSelect.addEventListener('change', () => {
    // Simula a atualização dos dados do gráfico ao trocar de serviço
    const selectedService = serviceSelect.value;
    let newData;

    switch (selectedService) {
        case 'buraco':
            newData = [22, 12, 10];
            break;
        case 'rede':
            newData = [10, 3, 7];
            break;
        case 'encanamento':
            newData = [15, 8, 7];
            break;
        case 'postes':
            newData = [17, 12, 5];
            break;
    }

    serviceChart.data.datasets[0].data = newData;
    serviceChart.update();
});


