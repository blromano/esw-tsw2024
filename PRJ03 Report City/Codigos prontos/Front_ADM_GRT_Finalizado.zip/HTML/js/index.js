const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const loginBtn = document.getElementById('login-btn');
const gerenteOption = document.getElementById('gerente-option');
const admOption = document.getElementById('adm-option');

function validateForm() {
    if (emailInput.value && passwordInput.value) {
        loginBtn.classList.add('active');
        loginBtn.classList.remove('inactive');
        loginBtn.removeAttribute('disabled');
    } else {
        loginBtn.classList.add('inactive');
        loginBtn.classList.remove('active');
        loginBtn.setAttribute('disabled', 'true');
    }
}

loginBtn.addEventListener('click', () => {
    if (loginBtn.classList.contains('active')) {
        if (admOption.checked) {
            window.location.href = 'adm_lobby.html';
        } else if (gerenteOption.checked) {
            window.location.href = 'grt_lobby.html';
        }
    }
});

emailInput.addEventListener('input', validateForm);
passwordInput.addEventListener('input', validateForm);
