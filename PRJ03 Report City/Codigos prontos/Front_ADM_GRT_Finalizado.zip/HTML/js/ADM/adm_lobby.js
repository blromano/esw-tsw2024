document.addEventListener('DOMContentLoaded', () => {
    // Modal de configurações (Engrenagem)
    const settingsModal = document.getElementById('settings-modal');
    const gearIcon = document.querySelector('.gear-icon');
    const settingsClose = settingsModal.querySelector('.close');
    const logoutBtn = document.getElementById('logout-btn');

    // Modal dos gerentes
    const managerModal = document.getElementById('manager-modal');
    const managerClose = managerModal.querySelector('.close');
    const arrowButtons = document.querySelectorAll('.arrow-btn');
    const managerName = document.getElementById('manager-name');
    const managerInfo = document.getElementById('manager-info');

    // Modal para adicionar novo gestor
    const addManagerModal = document.getElementById('add-manager-modal');
    const addBtn = document.getElementById('add-btn');
    const addManagerClose = addManagerModal.querySelector('.close');
    const createManagerBtn = document.getElementById('create-manager-btn');

    // Modal para deletar gestor
    const deleteManagerModal = document.getElementById('delete-manager-modal');
    const deleteBtn = document.getElementById('delete-btn');
    const deleteManagerClose = deleteManagerModal.querySelector('.close');
    const deleteManagerBtn = document.getElementById('delete-manager-btn');

    // Abre o modal de configurações ao clicar na engrenagem
    gearIcon.addEventListener('click', () => {
        settingsModal.style.display = 'block';
    });

    // Fecha o modal de configurações ao clicar no "X"
    settingsClose.addEventListener('click', () => {
        settingsModal.style.display = 'none';
    });

    // Fecha o modal de configurações ao clicar fora dele
    window.addEventListener('click', (event) => {
        if (event.target == settingsModal) {
            settingsModal.style.display = 'none';
        }
    });

    // Realiza o logout ao clicar no botão de logout
    logoutBtn.addEventListener('click', () => {
        window.location.href = 'index.html'; // Redireciona para a tela de login
    });

    // Abre o modal do gerente ao clicar na seta
    arrowButtons.forEach((button, index) => {
        button.addEventListener('click', () => {
            const managerNames = ['Erick Victor Teixeira', 'Gestor Nome 2', 'Gestor Nome 3'];
            const managerInfos = [
                'Informações detalhadas sobre Erick Victor Teixeira.',
                'Informações detalhadas sobre Gestor Nome 2.',
                'Informações detalhadas sobre Gestor Nome 3.'
            ];

            managerName.textContent = managerNames[index];
            managerInfo.textContent = managerInfos[index];

            managerModal.style.display = 'block';
        });
    });

    // Fecha o modal do gerente ao clicar no "X"
    managerClose.addEventListener('click', () => {
        managerModal.style.display = 'none';
    });

    // Fecha o modal do gerente ao clicar fora dele
    window.addEventListener('click', (event) => {
        if (event.target == managerModal) {
            managerModal.style.display = 'none';
        }
    });

    // Abre o modal para adicionar novo gestor ao clicar no botão "Novo Gestor"
    addBtn.addEventListener('click', () => {
        addManagerModal.style.display = 'block';
    });

    // Fecha o modal de adicionar novo gestor ao clicar no "X"
    addManagerClose.addEventListener('click', () => {
        addManagerModal.style.display = 'none';
    });

    // Fecha o modal de adicionar novo gestor ao clicar fora dele
    window.addEventListener('click', (event) => {
        if (event.target == addManagerModal) {
            addManagerModal.style.display = 'none';
        }
    });

    // Simula a criação de um novo gestor e fecha o modal
    createManagerBtn.addEventListener('click', (event) => {
        event.preventDefault(); // Evita o envio do formulário
        alert('Gestor criado!');
        addManagerModal.style.display = 'none';
    });

    // Abre o modal para deletar gestor ao clicar no botão "Deletar Gestor"
    deleteBtn.addEventListener('click', () => {
        deleteManagerModal.style.display = 'block';
    });

    // Fecha o modal de deletar gestor ao clicar no "X"
    deleteManagerClose.addEventListener('click', () => {
        deleteManagerModal.style.display = 'none';
    });

    // Fecha o modal de deletar gestor ao clicar fora dele
    window.addEventListener('click', (event) => {
        if (event.target == deleteManagerModal) {
            deleteManagerModal.style.display = 'none';
        }
    });

    // Simula a exclusão de um gestor e fecha o modal
    deleteManagerBtn.addEventListener('click', (event) => {
        event.preventDefault(); // Evita o envio do formulário
        alert('Gestor excluído!');
        deleteManagerModal.style.display = 'none';
    });
});
